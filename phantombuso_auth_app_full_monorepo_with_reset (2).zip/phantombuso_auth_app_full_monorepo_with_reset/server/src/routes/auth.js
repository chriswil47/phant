import express from 'express';
import bcrypt from 'bcryptjs';
import passport from 'passport';
import User from '../models/User.js';
import { signToken } from '../utils/jwt.js';
import crypto from 'crypto';
import ResetToken from '../models/ResetToken.js';
import { sendMail } from '../utils/mailer.js';
import verifyToken from '../middlewares/verifyToken.js';

const router = express.Router();

router.post('/register', async (req, res)=>{
  try{
    const { name, email, password } = req.body;
    if(!email || !password) return res.status(400).json({ message: 'Email and password required' });
    const exists = await User.findOne({ email });
    if(exists) return res.status(409).json({ message: 'User already exists' });
    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, passwordHash: hash });
    const token = signToken({ id: user._id, email });
    res.json({ token, user: { id: user._id, email, name: user.name } });
  }catch(e){ res.status(500).json({ message: 'Server error' }); }
});

router.post('/login', async (req, res)=>{
  try{
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if(!user) return res.status(401).json({ message: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.passwordHash);
    if(!ok) return res.status(401).json({ message: 'Invalid credentials' });
    const token = signToken({ id: user._id, email });
    res.json({ token, user: { id: user._id, email, name: user.name } });
  }catch(e){ res.status(500).json({ message: 'Server error' }); }
});

router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
router.get('/google/callback',
  passport.authenticate('google', { failureRedirect: '/' }),
  async (req, res) => {
    const token = signToken({ id: req.user._id, email: req.user.email });
    const redirect = (process.env.FRONTEND_URL || 'http://localhost:5173') + `/?token=${token}`;
    res.redirect(redirect);
  }
);

router.get('/github', passport.authenticate('github', { scope: ['user:email'] }));
router.get('/github/callback',
  passport.authenticate('github', { failureRedirect: '/' }),
  async (req, res) => {
    const token = signToken({ id: req.user._id, email: req.user.email });
    const redirect = (process.env.FRONTEND_URL || 'http://localhost:5173') + `/?token=${token}`;
    res.redirect(redirect);
  }
);

router.get('/me', verifyToken, async (req, res)=>{
  try{
    const user = await User.findById(req.user.id).lean();
    if(!user) return res.status(404).json({ message: 'User not found' });
    res.json({ user: { id: user._id, email: user.email, name: user.name } });
  }catch(e){ res.status(500).json({ message: 'Server error' }); }
});


// Request password reset (send email)
router.post('/forgot-password', async (req, res)=>{
  try{
    const { email } = req.body;
    if(!email) return res.status(400).json({ message: 'Email required' });
    const user = await User.findOne({ email });
    if(!user) return res.json({ message: 'If that email exists, a reset link has been sent.' });

    const token = (await import('crypto')).randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 60*60*1000);
    await ResetToken.deleteMany({ userId: user._id });
    await ResetToken.create({ userId: user._id, token, expiresAt });

    const frontend = process.env.FRONTEND_URL || 'http://localhost:5173';
    const link = `${frontend}/reset-password?token=${token}`;
    const html = `<p>Hello${user.name ? ' ' + user.name : ''},</p>
      <p>Use the link below to reset your PhantomBuSo password (expires in 1 hour):</p>
      <p><a href="${link}">${link}</a></p>`;

    try { await sendMail({ to: user.email, subject: 'Reset your PhantomBuSo password', html }); } catch(e){}
    return res.json({ message: 'If that email exists, a reset link has been sent.' });
  }catch(e){ return res.status(500).json({ message: 'Server error' }); }
});

// Reset password with token
router.post('/reset-password', async (req, res)=>{
  try{
    const { token, password } = req.body;
    if(!token || !password) return res.status(400).json({ message: 'Token and new password required' });
    const Reset = (await import('../models/ResetToken.js')).default;
    const B = (await import('bcryptjs')).default;
    const record = await Reset.findOne({ token });
    if(!record || record.expiresAt < new Date()) return res.status(400).json({ message: 'Invalid or expired token' });
    const user = await User.findById(record.userId);
    if(!user) return res.status(404).json({ message: 'User not found' });
    user.passwordHash = await B.hash(password, 10);
    await user.save();
    await Reset.deleteMany({ userId: user._id });
    return res.json({ message: 'Password has been reset successfully.' });
  }catch(e){ return res.status(500).json({ message: 'Server error' }); }
});

export default router;
