import jwt from 'jsonwebtoken';
export const signToken = (payload) => jwt.sign(payload, process.env.JWT_SECRET || 'change_me', { expiresIn: '7d' });
