import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import api from '../api/axios';
export default function ProtectedRoute({ children }){
  const [loading, setLoading] = useState(true);
  const [ok, setOk] = useState(false);
  useEffect(()=>{
    let m=true;
    (async()=>{
      try{ await api.get('/auth/me'); if(m) setOk(true); }
      catch{ if(m) setOk(false); }
      finally{ if(m) setLoading(false); }
    })();
    return ()=>{ m=false; };
  },[]);
  if(loading) return <div style={{color:'#fff',textAlign:'center',marginTop:'20vh'}}>Loading...</div>;
  if(!ok) return <Navigate to='/' replace />;
  return children;
}
