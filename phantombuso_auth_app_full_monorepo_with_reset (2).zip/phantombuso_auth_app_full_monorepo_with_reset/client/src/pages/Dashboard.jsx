import React, { useEffect, useState } from "react";
import api from "../api/axios";
export default function Dashboard(){
  const [user, setUser] = useState(null);
  useEffect(()=>{(async()=>{try{const {data}=await api.get('/auth/me');setUser(data.user);}catch(e){console.error(e);}})()},[]);
  return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'linear-gradient(135deg,#0b0b0f,#141428)'}}>
      <div style={{background:'#101020',padding:32,borderRadius:16,width:'100%',maxWidth:720,boxShadow:'0 10px 30px rgba(0,0,0,0.4)'}}>
        <h1 style={{color:'#b983ff'}}>Dashboard</h1>
        {user ? <pre style={{color:'#ddd'}}>{JSON.stringify(user,null,2)}</pre> : <p>Loading user...</p>}
        <div style={{marginTop:24}}>
          <a href="/" onClick={(e)=>{e.preventDefault(); localStorage.removeItem('pbso_token'); window.location.href='/';}} style={{padding:'10px 14px',borderRadius:8,background:'#dc2626',color:'#fff'}}>Logout</a>
        </div>
      </div>
    </div>
  );
}
