import React, { useState } from "react";
import api from "../api/axios";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function submit(e){
    e.preventDefault();
    setError("");
    try{
      const { data } = await api.post("/auth/login", { email, password });
      localStorage.setItem("pbso_token", data.token);
      window.location.href = "/dashboard";
    }catch(err){
      setError(err?.response?.data?.message || "Login failed");
    }
  }

  function google(){ window.location.href = "/api/auth/google"; }
  function github(){ window.location.href = "/api/auth/github"; }

  return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'linear-gradient(135deg,#0b0b0f,#141428)'}}>
      <div style={{background:'#101020',padding:32,borderRadius:16,width:'100%',maxWidth:420,boxShadow:'0 10px 30px rgba(0,0,0,0.4)'}}>
        <h1 style={{textAlign:'center',marginBottom:24,color:'#b983ff'}}>Login</h1>
        <form onSubmit={submit} style={{display:'grid',gap:16}}>
          <div>
            <label>Email</label>
            <input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="you@example.com" style={{width:'100%',padding:12,borderRadius:8,border:'1px solid #333',background:'#1a1a2e',color:'#fff'}}/>
          </div>
          <div>
            <label>Password</label>
            <input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="••••••••" style={{width:'100%',padding:12,borderRadius:8,border:'1px solid #333',background:'#1a1a2e',color:'#fff'}}/>
          </div>
          <div style={{textAlign:'right'}}>
            <a href="/forgot-password" style={{color:'#b983ff',fontSize:14}}>Forgot password?</a>
          </div>
          {error && <div style={{color:'#ff6b6b',fontSize:14}}>{error}</div>}
          <button style={{width:'100%',padding:12,borderRadius:10,background:'linear-gradient(90deg,#7c3aed,#2563eb)',color:'#fff',fontWeight:600}}>Sign In</button>
        </form>
        <div style={{marginTop:16,textAlign:'center',fontSize:14,color:'#bbb'}}>Or continue with</div>
        <div style={{display:'flex',gap:10,justifyContent:'center',marginTop:10}}>
          <button onClick={google} style={{padding:'8px 14px',borderRadius:8,border:'1px solid #333',background:'transparent',color:'#fff'}}>Google</button>
          <button onClick={github} style={{padding:'8px 14px',borderRadius:8,border:'1px solid #333',background:'transparent',color:'#fff'}}>GitHub</button>
        </div>
      </div>
    </div>
  );
}
