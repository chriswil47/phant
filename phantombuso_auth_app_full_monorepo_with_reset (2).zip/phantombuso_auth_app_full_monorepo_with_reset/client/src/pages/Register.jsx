import React, { useState } from "react";
import api from "../api/axios";

export default function Register(){
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  async function submit(e){
    e.preventDefault();
    setMsg(""); setErr("");
    try{
      const { data } = await api.post("/auth/register", { name, email, password });
      localStorage.setItem("pbso_token", data.token);
      setMsg("Account created!");
      window.location.href = "/dashboard";
    }catch(error){
      setErr(error?.response?.data?.message || "Signup failed");
    }
  }

  return (
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'linear-gradient(135deg,#0b0b0f,#141428)'}}>
      <div style={{background:'#101020',padding:32,borderRadius:16,width:'100%',maxWidth:420,boxShadow:'0 10px 30px rgba(0,0,0,0.4)'}}>
        <h1 style={{textAlign:'center',marginBottom:24,color:'#b983ff'}}>Create Account</h1>
        <form onSubmit={submit} style={{display:'grid',gap:16}}>
          <div><label>Full name</label><input value={name} onChange={e=>setName(e.target.value)} type="text" placeholder="Jane Doe" style={{width:'100%',padding:12,borderRadius:8,border:'1px solid #333',background:'#1a1a2e',color:'#fff'}}/></div>
          <div><label>Email</label><input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="you@example.com" style={{width:'100%',padding:12,borderRadius:8,border:'1px solid #333',background:'#1a1a2e',color:'#fff'}}/></div>
          <div><label>Password</label><input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Choose a secure password" style={{width:'100%',padding:12,borderRadius:8,border:'1px solid #333',background:'#1a1a2e',color:'#fff'}}/></div>
          {err && <div style={{color:'#ff6b6b',fontSize:14}}>{err}</div>}
          {msg && <div style={{color:'#2dd4bf',fontSize:14}}>{msg}</div>}
          <button style={{width:'100%',padding:12,borderRadius:10,background:'linear-gradient(90deg,#7c3aed,#2563eb)',color:'#fff',fontWeight:600}}>Create Account</button>
        </form>
      </div>
    </div>
  );
}
