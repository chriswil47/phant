import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import api from "../api/axios";
export default function ResetPassword(){
  const location = useLocation();
  const navigate = useNavigate();
  const [token, setToken] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  useEffect(()=>{ const p = new URLSearchParams(location.search); setToken(p.get("token")||""); },[location.search]);
  async function submit(e){
    e.preventDefault(); setMsg(""); setErr("");
    try{ const { data } = await api.post("/auth/reset-password", { token, password });
      setMsg(data.message || "Password reset."); setTimeout(()=> navigate("/"), 1500); }
    catch(error){ setErr(error?.response?.data?.message || "Something went wrong."); }
  }
  return (<div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'linear-gradient(135deg,#0b0b0f,#141428)'}}>
    <div style={{background:'#101020',padding:32,borderRadius:16,width:'100%',maxWidth:420,boxShadow:'0 10px 30px rgba(0,0,0,0.4)'}}>
      <h1 style={{textAlign:'center',marginBottom:24,color:'#b983ff'}}>Set New Password</h1>
      <form onSubmit={submit} style={{display:'grid',gap:16}}>
        <div><label>New password</label><input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Choose a secure password" style={{width:'100%',padding:12,borderRadius:8,border:'1px solid #333',background:'#1a1a2e',color:'#fff'}}/></div>
        {msg && <div style={{color:'#2dd4bf',fontSize:14}}>{msg}</div>}
        {err && <div style={{color:'#ff6b6b',fontSize:14}}>{err}</div>}
        <button type="submit" style={{width:'100%',padding:12,borderRadius:10,background:'linear-gradient(90deg,#2563eb,#7c3aed)',color:'#fff',fontWeight:600}}>Update Password</button>
      </form>
    </div></div>);
}