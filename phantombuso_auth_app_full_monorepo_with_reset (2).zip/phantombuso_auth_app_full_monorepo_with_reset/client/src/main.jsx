import React, { useEffect } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import Dashboard from './pages/Dashboard'
import ProtectedRoute from './routes/ProtectedRoute'

function TokenCatcher(){
  const location = useLocation();
  const navigate = useNavigate();
  useEffect(()=>{
    const params = new URLSearchParams(location.search);
    const token = params.get('token');
    if(token){
      localStorage.setItem('pbso_token', token);
      navigate('/dashboard', { replace: true });
    }
  }, [location.search, navigate]);
  return null;
}

function Shell({ children }){
  return (
    <>
      <div style={{padding:16,color:'#fff'}}>
        <nav style={{maxWidth:1200,margin:'0 auto',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div style={{fontWeight:800,color:'#b983ff'}}>PhantomBuSo</div>
          <div style={{display:'flex',gap:12}}>
            <Link to='/' style={{color:'#ddd'}}>Login</Link>
            <Link to='/register' style={{color:'#ddd'}}>Register</Link>
            <Link to='/dashboard' style={{color:'#ddd'}}>Dashboard</Link>
          </div>
        </nav>
      </div>
      {children}
    </>
  )
}

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <TokenCatcher />
      <Shell>
        <Routes>
          <Route path='/' element={<Login />} />
          <Route path='/register' element={<Register />} />
          <Route path='/forgot-password' element={<ForgotPassword />} />
          <Route path='/dashboard' element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
                  <Route path='/reset-password' element={<ResetPassword />} />
        </Routes>
      </Shell>
    </BrowserRouter>
  </React.StrictMode>
)
