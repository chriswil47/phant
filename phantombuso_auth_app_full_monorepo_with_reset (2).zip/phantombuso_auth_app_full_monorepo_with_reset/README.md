# PhantomBuSo Auth Monorepo

- client/: Vite + React frontend (OAuth wired)
- server/: Express backend with JWT + Google/GitHub OAuth

## Local
npm run install:all
cp server/.env.example server/.env  # set secrets
npm run dev

## Build + start
npm run build
npm start
